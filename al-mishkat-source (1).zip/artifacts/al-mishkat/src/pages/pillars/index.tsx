import { Link } from "wouter";
import { useListPillars } from "@workspace/api-client-react";
import { Layout } from "@/components/layout/Layout";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

export default function PillarsList() {
  const { data: pillars, isLoading, isError, refetch } = useListPillars();

  return (
    <Layout>
      <div className="bg-primary text-primary-foreground py-16 border-b border-primary-border">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h2 className="text-3xl font-serif text-accent mb-3" dir="rtl">أركان الإسلام</h2>
          <h1 className="text-4xl font-serif font-bold mb-4">The Five Pillars of Islam</h1>
          <p className="text-primary-foreground/80 text-lg">
            The five pillars are the core practices that every Muslim must follow — the foundation of Islamic faith and practice.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {isLoading ? (
          <LoadingState message="Loading pillars..." />
        ) : isError ? (
          <ErrorState message="Failed to load pillars." onRetry={() => refetch()} />
        ) : pillars && pillars.length > 0 ? (
          <div className="flex flex-col gap-6">
            {pillars.sort((a, b) => a.order - b.order).map((pillar) => (
              <Link key={pillar.id} href={`/pillars/${pillar.id}`}>
                <Card className="hover-elevate cursor-pointer border-border hover:border-primary/40 transition-all group">
                  <CardContent className="p-6 flex items-start gap-6">
                    <div className="w-16 h-16 shrink-0 rounded-full bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <span className="font-serif text-xl font-bold">{pillar.order}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-3">
                          <h2 className="text-xl font-bold group-hover:text-primary transition-colors">{pillar.name}</h2>
                          <span className="font-serif text-lg text-accent" dir="rtl">{pillar.arabicName}</span>
                        </div>
                        <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
                      </div>
                      <p className="text-foreground/65 leading-relaxed">{pillar.shortDescription}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <ErrorState title="No Pillars Found" message="Pillar content is not yet available." />
        )}
      </div>
    </Layout>
  );
}
